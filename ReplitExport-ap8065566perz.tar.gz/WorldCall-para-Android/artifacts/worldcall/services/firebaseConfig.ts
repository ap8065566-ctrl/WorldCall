import { getApp, getApps, initializeApp } from "firebase/app";

const firebaseConfig = {
  apiKey: "AIzaSyBixDIMn7BfEZDvdSdNFOxL",
  authDomain: "worldcall-7ca25.firebaseapp.com",
  projectId: "worldcall-7ca25",
  messagingSenderId: "270544540110",
  appId: "1:270544540110:web:e254c9df35",
};

export const firebaseApp = getApps().length
  ? getApp()
  : initializeApp(firebaseConfig);
