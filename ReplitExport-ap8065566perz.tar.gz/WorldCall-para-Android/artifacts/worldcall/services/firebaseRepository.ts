import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  type User,
} from "firebase/auth";
import {
  doc,
  getDoc,
  serverTimestamp,
  setDoc,
} from "firebase/firestore";
import type { Gender, MemberProfile } from "@/types/worldcall";
import { auth, db } from "@/services/firebase";

const PROFILE_COLLECTION = "profiles";

const GENDERS: Gender[] = ["Mujer", "Hombre", "Prefiero no decirlo"];

function normalizePhotoUrl(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const url = value.trim();
  if (
    !/^https:\/\/[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?(?::\d{1,5})?(?:[/?#][^\s]*)?$/i.test(
      url,
    ) ||
    url.includes("firebasestorage.googleapis.com/")
  ) {
    return null;
  }
  return url;
}

function isProfile(value: unknown): value is MemberProfile {
  if (!value || typeof value !== "object") return false;
  const profile = value as Partial<MemberProfile>;
  return (
    typeof profile.name === "string" &&
    profile.name.trim().length >= 2 &&
    typeof profile.age === "number" &&
    Number.isInteger(profile.age) &&
    profile.age >= 18 &&
    profile.age <= 120 &&
    GENDERS.includes(profile.gender as Gender) &&
    typeof profile.country === "string" &&
    profile.country.length > 0 &&
    (typeof profile.photoUri === "string" || profile.photoUri === null)
  );
}

export async function getFirebaseProfile(
  userId: string,
): Promise<MemberProfile | null> {
  const profileSnapshot = await getDoc(
    doc(db, PROFILE_COLLECTION, userId),
  );
  if (!profileSnapshot.exists()) return null;

  const data = profileSnapshot.data();
  if (!isProfile(data)) {
    throw new Error(
      "El perfil guardado en Firebase no tiene un formato válido. Revisa los datos del perfil.",
    );
  }
  return { ...data, photoUri: normalizePhotoUrl(data.photoUri) };
}

export async function saveFirebaseProfile(
  user: User,
  profile: MemberProfile,
): Promise<MemberProfile> {
  const profileRef = doc(db, PROFILE_COLLECTION, user.uid);
  const previousSnapshot = await getDoc(profileRef);
  const photoUri = normalizePhotoUrl(profile.photoUri);
  await setDoc(profileRef, {
    name: profile.name,
    age: profile.age,
    gender: profile.gender,
    country: profile.country,
    photoUri,
    createdAt: previousSnapshot.exists()
      ? previousSnapshot.data().createdAt ?? serverTimestamp()
      : serverTimestamp(),
    updatedAt: serverTimestamp(),
  });

  return { ...profile, photoUri };
}

export async function createFirebaseAccount(
  email: string,
  password: string,
  profile: MemberProfile,
): Promise<{ user: User; profile: MemberProfile }> {
  const credential = await createUserWithEmailAndPassword(
    auth,
    email.trim(),
    password,
  );
  try {
    const savedProfile = await saveFirebaseProfile(credential.user, profile);
    return { user: credential.user, profile: savedProfile };
  } catch (error) {
    await signOut(auth).catch(() => undefined);
    throw error;
  }
}

export async function signInToFirebase(
  email: string,
  password: string,
): Promise<{ user: User; profile: MemberProfile | null }> {
  const credential = await signInWithEmailAndPassword(
    auth,
    email.trim(),
    password,
  );
  try {
    const profile = await getFirebaseProfile(credential.user.uid);
    return { user: credential.user, profile };
  } catch (error) {
    await signOut(auth).catch(() => undefined);
    throw error;
  }
}

export async function signOutFromFirebase(): Promise<void> {
  await signOut(auth);
}

export function firebaseErrorMessage(error: unknown): string {
  const code =
    error && typeof error === "object" && "code" in error
      ? String(error.code)
      : "";

  switch (code) {
    case "auth/operation-not-allowed":
      return "Activa el acceso por correo y contraseña en Firebase Authentication.";
    case "auth/email-already-in-use":
      return "Ya existe una cuenta con ese correo. Inicia sesión en su lugar.";
    case "auth/invalid-email":
      return "Escribe una dirección de correo válida.";
    case "auth/weak-password":
      return "La contraseña debe tener al menos 6 caracteres.";
    case "auth/invalid-credential":
    case "auth/wrong-password":
    case "auth/user-not-found":
      return "El correo o la contraseña no son correctos.";
    case "auth/too-many-requests":
      return "Hubo demasiados intentos. Espera un momento y vuelve a intentarlo.";
    case "auth/network-request-failed":
      return "No hay conexión con Firebase. Revisa tu conexión e inténtalo de nuevo.";
    case "permission-denied":
      return "Firestore rechazó el acceso. Comprueba que las reglas de WorldCall estén publicadas.";
    default:
      if (error instanceof Error && error.message) return error.message;
      return "No se pudo completar la operación en Firebase. Comprueba la configuración y vuelve a intentarlo.";
  }
}
