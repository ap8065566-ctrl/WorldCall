import AsyncStorage from '@react-native-async-storage/async-storage';
import type {
  MatchFilters,
  MemberProfile,
} from '@/types/worldcall';

const KEYS = {
  profile: '@worldcall/profile-v1',
  filters: '@worldcall/filters-v1',
  blocked: '@worldcall/blocked-v1',
  reported: '@worldcall/reported-v1',
  reports: '@worldcall/reports-v1',
};

export const DEFAULT_FILTERS: MatchFilters = {
  gender: 'Todos',
  ageRange: 'Todas',
  country: 'Cualquier país',
};

export interface LocalSnapshot {
  profile: MemberProfile | null;
  filters: MatchFilters;
  blockedIds: string[];
  reportedIds: string[];
}

export interface WorldCallRepository {
  load(): Promise<LocalSnapshot>;
  clearLegacyProfile(): Promise<void>;
  saveFilters(filters: MatchFilters): Promise<void>;
  blockProfile(matchId: string): Promise<string[]>;
  submitReport(matchId: string, reason: string): Promise<string[]>;
}

function parseJson(value: string | null): unknown {
  if (!value) return null;
  try {
    return JSON.parse(value);
  } catch {
    return null;
  }
}

function parseStringArray(value: string | null): string[] {
  const parsed = parseJson(value);
  return Array.isArray(parsed)
    ? parsed.filter((item): item is string => typeof item === 'string')
    : [];
}

function isMemberProfile(value: unknown): value is MemberProfile {
  if (!value || typeof value !== 'object') return false;
  const profile = value as Partial<MemberProfile>;
  return (
    typeof profile.name === 'string' &&
    profile.name.trim().length >= 2 &&
    typeof profile.age === 'number' &&
    Number.isInteger(profile.age) &&
    profile.age >= 18 &&
    (profile.gender === 'Mujer' ||
      profile.gender === 'Hombre' ||
      profile.gender === 'Prefiero no decirlo') &&
    typeof profile.country === 'string' &&
    (typeof profile.photoUri === 'string' || profile.photoUri === null)
  );
}

function isMatchFilters(value: unknown): value is MatchFilters {
  if (!value || typeof value !== 'object') return false;
  const filters = value as Partial<MatchFilters>;
  return (
    (filters.gender === 'Todos' ||
      filters.gender === 'Mujeres' ||
      filters.gender === 'Hombres') &&
    (filters.ageRange === 'Todas' ||
      filters.ageRange === '18-24' ||
      filters.ageRange === '25-34' ||
      filters.ageRange === '35-49' ||
      filters.ageRange === '50+') &&
    typeof filters.country === 'string'
  );
}

async function load(): Promise<LocalSnapshot> {
  const entries = await AsyncStorage.multiGet(Object.values(KEYS));
  const stored = new Map(entries);
  const profileValue = parseJson(stored.get(KEYS.profile) ?? null);
  const filtersValue = parseJson(stored.get(KEYS.filters) ?? null);
  return {
    profile: isMemberProfile(profileValue) ? profileValue : null,
    filters: isMatchFilters(filtersValue) ? filtersValue : DEFAULT_FILTERS,
    blockedIds: parseStringArray(stored.get(KEYS.blocked) ?? null),
    reportedIds: parseStringArray(stored.get(KEYS.reported) ?? null),
  };
}

async function clearLegacyProfile(): Promise<void> {
  await AsyncStorage.removeItem(KEYS.profile);
}

async function saveFilters(filters: MatchFilters): Promise<void> {
  await AsyncStorage.setItem(KEYS.filters, JSON.stringify(filters));
}

async function appendId(key: string, matchId: string): Promise<string[]> {
  const current = parseStringArray(await AsyncStorage.getItem(key));
  const updated = [...new Set([...current, matchId])];
  await AsyncStorage.setItem(key, JSON.stringify(updated));
  return updated;
}

async function blockProfile(matchId: string): Promise<string[]> {
  return appendId(KEYS.blocked, matchId);
}

async function submitReport(
  matchId: string,
  reason: string,
): Promise<string[]> {
  const reportsValue = parseJson(await AsyncStorage.getItem(KEYS.reports));
  const reports = Array.isArray(reportsValue) ? reportsValue : [];
  reports.push({
    matchId,
    reason,
    createdAt: new Date().toISOString(),
  });
  const reportedIds = await appendId(KEYS.reported, matchId);
  await AsyncStorage.setItem(KEYS.reports, JSON.stringify(reports));
  return reportedIds;
}

// The profile key is read only to prefill the first Firebase registration.
// Preferences and moderation data intentionally remain on this device.
export const localRepository: WorldCallRepository = {
  load,
  clearLegacyProfile,
  saveFilters,
  blockProfile,
  submitReport,
};
