import type { AgeRange, DemoMatch, MatchFilters } from '@/types/worldcall';

export const DEMO_MATCHES: DemoMatch[] = [
  {
    id: 'lucia-es',
    name: 'Lucía',
    age: 27,
    gender: 'Mujer',
    country: 'España',
    city: 'Barcelona',
    photo: require('../assets/images/profile-lucia.jpg'),
  },
  {
    id: 'mateus-br',
    name: 'Mateus',
    age: 32,
    gender: 'Hombre',
    country: 'Brasil',
    city: 'Río de Janeiro',
    photo: require('../assets/images/profile-mateus.jpg'),
  },
  {
    id: 'yui-jp',
    name: 'Yui',
    age: 29,
    gender: 'Mujer',
    country: 'Japón',
    city: 'Tokio',
    photo: require('../assets/images/profile-yui.jpg'),
  },
];

function isInAgeRange(age: number, range: AgeRange): boolean {
  if (range === 'Todas') return age >= 18;
  if (range === '50+') return age >= 50;

  const min = Number(range.split('-')[0]);
  const max = Number(range.split('-')[1]);
  return age >= min && age <= max;
}

export function findDemoMatch(
  filters: MatchFilters,
  excludedId: string | null,
  blockedIds: string[],
  reportedIds: string[],
): DemoMatch | null {
  const candidates = DEMO_MATCHES.filter((match) => {
    if (match.age < 18 || match.id === excludedId) return false;
    if (blockedIds.includes(match.id) || reportedIds.includes(match.id)) return false;
    if (filters.gender === 'Mujeres' && match.gender !== 'Mujer') return false;
    if (filters.gender === 'Hombres' && match.gender !== 'Hombre') return false;
    if (filters.country !== 'Cualquier país' && match.country !== filters.country) {
      return false;
    }
    return isInAgeRange(match.age, filters.ageRange);
  });

  if (candidates.length === 0) return null;
  return candidates[Math.floor(Math.random() * candidates.length)] ?? null;
}
