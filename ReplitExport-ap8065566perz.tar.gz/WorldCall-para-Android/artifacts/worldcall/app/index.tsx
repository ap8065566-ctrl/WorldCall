import { useEffect, useRef, useState } from 'react';
import { Alert, Text, View } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { onAuthStateChanged, type User } from 'firebase/auth';
import { useColors } from '@/hooks/useColors';
import type {
  DemoMatch,
  MatchFilters,
  MemberProfile,
} from '@/types/worldcall';
import { findDemoMatch } from '@/data/demoProfiles';
import { HomeScreen } from '@/components/worldcall/HomeScreen';
import { ProfileScreen } from '@/components/worldcall/ProfileScreen';
import { LoginScreen } from '@/components/worldcall/LoginScreen';
import { SearchingScreen, CallScreen } from '@/components/worldcall/SearchAndCallScreens';
import { WelcomeScreen } from '@/components/worldcall/WelcomeScreen';
import {
  DEFAULT_FILTERS,
  localRepository,
  type LocalSnapshot,
} from '@/services/localRepository';
import { auth } from '@/services/firebase';
import {
  createFirebaseAccount,
  firebaseErrorMessage,
  getFirebaseProfile,
  saveFirebaseProfile,
  signInToFirebase,
  signOutFromFirebase,
} from '@/services/firebaseRepository';

type Screen =
  | 'loading'
  | 'welcome'
  | 'login'
  | 'profile'
  | 'home'
  | 'searching'
  | 'call';

interface SearchRequest {
  filters: MatchFilters;
  excludedId: string | null;
  blockedIds: string[];
  reportedIds: string[];
}

export default function WorldCallApp() {
  const colors = useColors();
  const [screen, setScreen] = useState<Screen>('loading');
  const [authUser, setAuthUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<MemberProfile | null>(null);
  const [legacyProfile, setLegacyProfile] = useState<MemberProfile | null>(null);
  const [filters, setFilters] = useState<MatchFilters>(DEFAULT_FILTERS);
  const [match, setMatch] = useState<DemoMatch | null>(null);
  const [blockedIds, setBlockedIds] = useState<string[]>([]);
  const [reportedIds, setReportedIds] = useState<string[]>([]);
  const [notice, setNotice] = useState('');
  const request = useRef<SearchRequest>({
    filters: DEFAULT_FILTERS,
    excludedId: null,
    blockedIds: [],
    reportedIds: [],
  });

  useEffect(() => {
    let mounted = true;
    let initialAuthResolved = false;
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (initialAuthResolved) return;
      initialAuthResolved = true;

      void (async () => {
        let snapshot: LocalSnapshot = {
          profile: null,
          filters: DEFAULT_FILTERS,
          blockedIds: [],
          reportedIds: [],
        };
        try {
          snapshot = await localRepository.load();
        } catch {
          if (!mounted) return;
          Alert.alert(
            'No se pudieron cargar las preferencias locales',
            'Puedes continuar con tu cuenta; las preferencias locales se reiniciarán.',
          );
        }

        if (!mounted) return;
        setFilters(snapshot.filters);
        setBlockedIds(snapshot.blockedIds);
        setReportedIds(snapshot.reportedIds);
        request.current = {
          filters: snapshot.filters,
          excludedId: null,
          blockedIds: snapshot.blockedIds,
          reportedIds: snapshot.reportedIds,
        };

        if (user) {
          try {
            const remoteProfile = await getFirebaseProfile(user.uid);
            if (!mounted) return;
            setAuthUser(user);
            setProfile(remoteProfile);
            setLegacyProfile(null);
            setScreen(remoteProfile ? 'home' : 'profile');
          } catch (error) {
            await signOutFromFirebase().catch(() => undefined);
            if (!mounted) return;
            setAuthUser(null);
            setProfile(null);
            setLegacyProfile(snapshot.profile);
            setScreen('welcome');
            Alert.alert(
              'No se pudo cargar el perfil de Firebase',
              firebaseErrorMessage(error),
            );
          }
          return;
        }

        setAuthUser(null);
        setProfile(null);
        setLegacyProfile(snapshot.profile);
        setScreen('welcome');
      })();
    });
    return () => {
      mounted = false;
      unsubscribe();
    };
  }, []);

  useEffect(() => {
    if (screen !== 'searching') return;
    const timeout = setTimeout(() => {
      const found = findDemoMatch(
        request.current.filters,
        request.current.excludedId,
        request.current.blockedIds,
        request.current.reportedIds,
      );
      if (found) {
        setMatch(found);
        setNotice('');
        setScreen('call');
      } else {
        setMatch(null);
        setNotice(
          'No hay perfiles de ejemplo que coincidan ahora. Prueba otros filtros.',
        );
        setScreen('home');
      }
    }, 1150);
    return () => clearTimeout(timeout);
  }, [screen]);

  const updateFilters = (updated: MatchFilters) => {
    setFilters(updated);
    request.current = { ...request.current, filters: updated };
    void localRepository.saveFilters(updated).catch(() => {
      setNotice('No se pudieron guardar las preferencias en este dispositivo.');
    });
  };

  const saveProfile = async (
    updated: MemberProfile,
    credentials: { email: string; password: string } | null,
  ) => {
    let nextUser = authUser;
    let savedProfile = updated;

    if (credentials) {
      const created = await createFirebaseAccount(
        credentials.email,
        credentials.password,
        updated,
      );
      nextUser = created.user;
      savedProfile = created.profile;
      await localRepository.clearLegacyProfile().catch((error) => {
        console.warn('Could not remove the migrated local profile draft.', error);
      });
    } else if (nextUser) {
      savedProfile = await saveFirebaseProfile(nextUser, updated);
    } else {
      throw new Error('Inicia sesión o crea una cuenta antes de guardar el perfil.');
    }

    setAuthUser(nextUser);
    setLegacyProfile(null);
    setProfile(savedProfile);
    setScreen('home');
  };

  const logIn = async (email: string, password: string) => {
    const result = await signInToFirebase(email, password);
    setAuthUser(result.user);
    setProfile(result.profile);
    setLegacyProfile(null);
    setScreen(result.profile ? 'home' : 'profile');
  };

  const logOut = async () => {
    try {
      await signOutFromFirebase();
      setAuthUser(null);
      setProfile(null);
      setMatch(null);
      setLegacyProfile(null);
      setScreen('welcome');
    } catch (error) {
      Alert.alert('No se pudo cerrar sesión', firebaseErrorMessage(error));
    }
  };

  const cancelProfile = async () => {
    if (authUser && !profile) {
      try {
        await signOutFromFirebase();
        setAuthUser(null);
        setScreen('welcome');
      } catch (error) {
        Alert.alert('No se pudo cerrar sesión', firebaseErrorMessage(error));
      }
      return;
    }
    setScreen(authUser ? 'home' : 'welcome');
  };

  const beginSearch = (overrides?: Partial<SearchRequest>) => {
    request.current = {
      filters,
      excludedId: null,
      blockedIds,
      reportedIds,
      ...overrides,
    };
    setNotice('');
    setScreen('searching');
  };

  const blockMatch = async () => {
    if (!match) return;
    try {
      const updated = await localRepository.blockProfile(match.id);
      setBlockedIds(updated);
      beginSearch({
        excludedId: match.id,
        blockedIds: updated,
        reportedIds,
      });
    } catch {
      Alert.alert(
        'No se pudo bloquear',
        'No se pudo guardar el bloqueo en este dispositivo.',
      );
    }
  };

  const reportMatch = async (reason: string) => {
    if (!match) return;
    try {
      const updated = await localRepository.submitReport(match.id, reason);
      setReportedIds(updated);
      beginSearch({
        excludedId: match.id,
        blockedIds,
        reportedIds: updated,
      });
    } catch {
      Alert.alert(
        'No se pudo enviar la denuncia',
        'No se pudo guardar en este dispositivo. Inténtalo otra vez.',
      );
    }
  };

  if (screen === 'loading') {
    return <HomeLoading colors={colors} />;
  }

  if (screen === 'welcome') {
    return (
      <WelcomeScreen
        hasLocalDraft={Boolean(legacyProfile)}
        onCreate={() => setScreen('profile')}
        onLogin={() => setScreen('login')}
      />
    );
  }

  if (screen === 'login') {
    return (
      <LoginScreen
        onLogin={logIn}
        onCancel={() => setScreen('welcome')}
      />
    );
  }

  if (screen === 'profile') {
    return (
      <ProfileScreen
        initialProfile={profile ?? (authUser ? null : legacyProfile)}
        isNewAccount={!authUser}
        onSave={saveProfile}
        onCancel={() => void cancelProfile()}
      />
    );
  }

  if (!profile) {
    return (
      <WelcomeScreen
        hasLocalDraft={Boolean(legacyProfile)}
        onCreate={() => setScreen('profile')}
        onLogin={() => setScreen('login')}
      />
    );
  }

  if (screen === 'searching') {
    return <SearchingScreen onCancel={() => setScreen('home')} />;
  }

  if (screen === 'call' && match) {
    return (
      <CallScreen
        match={match}
        profile={profile}
        onNext={() => beginSearch({ excludedId: match.id })}
        onBlock={() => void blockMatch()}
        onReport={(reason) => void reportMatch(reason)}
      />
    );
  }

  return (
    <HomeScreen
      profile={profile}
      filters={filters}
      notice={notice}
      onFiltersChange={updateFilters}
      onSearch={() => beginSearch()}
      onProfile={() => setScreen('profile')}
      onSignOut={() => void logOut()}
      onDismissNotice={() => setNotice('')}
    />
  );
}

function HomeLoading({ colors }: { colors: ReturnType<typeof useColors> }) {
  return (
    <View
      style={{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: colors.background,
        gap: 12,
      }}
    >
      <Feather name="globe" size={32} color={colors.primary} />
      <Text style={{ color: colors.mutedForeground, fontFamily: 'Inter_500Medium' }}>
        Cargando WorldCall…
      </Text>
    </View>
  );
}
