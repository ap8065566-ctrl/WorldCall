import { useState } from 'react';
import {
  Alert,
  Image,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useColors } from '@/hooks/useColors';
import type { Gender, MemberProfile } from '@/types/worldcall';
import { firebaseErrorMessage } from '@/services/firebaseRepository';
import { AppButton, AppScreen, BackButton, ChoiceChip, StepTitle } from './ui';
import { CountryPicker } from './CountryPicker';

const GENDERS: Gender[] = ['Mujer', 'Hombre', 'Prefiero no decirlo'];
const PHOTO_URL_PATTERN =
  /^https:\/\/[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?(?::\d{1,5})?(?:[/?#][^\s]*)?$/i;

function isSupportedPhotoUrl(value: string | null | undefined): value is string {
  return Boolean(
    value &&
      PHOTO_URL_PATTERN.test(value.trim()) &&
      !value.includes('firebasestorage.googleapis.com/'),
  );
}

export function ProfileScreen({
  initialProfile,
  isNewAccount,
  onSave,
  onCancel,
}: {
  initialProfile: MemberProfile | null;
  isNewAccount: boolean;
  onSave: (
    profile: MemberProfile,
    credentials: { email: string; password: string } | null,
  ) => Promise<void>;
  onCancel: () => void;
}) {
  const colors = useColors();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [passwordConfirmation, setPasswordConfirmation] = useState('');
  const [name, setName] = useState(initialProfile?.name ?? '');
  const [age, setAge] = useState(
    initialProfile?.age ? String(initialProfile.age) : '',
  );
  const [gender, setGender] = useState<Gender | null>(
    initialProfile?.gender ?? null,
  );
  const [country, setCountry] = useState(initialProfile?.country ?? '');
  const [photoUri, setPhotoUri] = useState(
    isSupportedPhotoUrl(initialProfile?.photoUri)
      ? initialProfile.photoUri
      : '',
  );
  const [confirmedAdult, setConfirmedAdult] = useState(
    initialProfile !== null,
  );
  const [countryPickerVisible, setCountryPickerVisible] = useState(false);
  const [saving, setSaving] = useState(false);

  const parsedAge = Number(age);
  const validAge = Number.isInteger(parsedAge) && parsedAge >= 18 && parsedAge <= 120;
  const invalidAge = age.length > 0 && !validAge;
  const validEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
  const validPassword = password.length >= 6;
  const matchingPasswords = password === passwordConfirmation;
  const trimmedPhotoUri = photoUri.trim();
  const validPhotoUri =
    !trimmedPhotoUri ||
    (PHOTO_URL_PATTERN.test(trimmedPhotoUri) &&
      !trimmedPhotoUri.includes('firebasestorage.googleapis.com/'));
  const ready =
    name.trim().length >= 2 &&
    validAge &&
    gender !== null &&
    country.length > 0 &&
    validPhotoUri &&
    confirmedAdult &&
    (!isNewAccount ||
      (validEmail && validPassword && matchingPasswords));

  const submit = async () => {
    if (!validAge) {
      Alert.alert(
        'Edad no válida',
        'WorldCall es solo para personas mayores de 18 años.',
      );
      return;
    }
    if (!ready || !gender) return;

    setSaving(true);
    try {
      await onSave({
        name: name.trim(),
        age: parsedAge,
        gender,
        country,
        photoUri: trimmedPhotoUri || null,
      }, isNewAccount ? { email: email.trim(), password } : null);
    } catch (error) {
      Alert.alert(
        'No se pudo guardar el perfil',
        firebaseErrorMessage(error),
      );
    } finally {
      setSaving(false);
    }
  };

  return (
    <AppScreen>
      <KeyboardAwareScrollViewCompat
        contentContainerStyle={styles.content}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
        bottomOffset={70}
      >
        <BackButton onPress={onCancel} />
        <View style={styles.heading}>
          <StepTitle
            eyebrow="TU PERFIL · 18+"
            title={
              isNewAccount
                ? 'Crea tu cuenta'
                : initialProfile
                  ? 'Actualiza tu perfil'
                  : 'Completa tu perfil'
            }
            detail={
              isNewAccount
                ? 'Usa un correo y una contraseña para guardar tu perfil en WorldCall.'
                : 'Con estos datos buscamos una conversación que encaje contigo.'
            }
          />
        </View>

        {isNewAccount ? (
          <View style={styles.accountFields}>
            <View style={styles.fieldGroup}>
              <Text style={[styles.label, { color: colors.foreground }]}>
                Correo electrónico
              </Text>
              <TextInput
                accessibilityLabel="Correo electrónico"
                autoCapitalize="none"
                autoComplete="email"
                autoCorrect={false}
                keyboardType="email-address"
                maxLength={254}
                onChangeText={setEmail}
                placeholder="nombre@ejemplo.com"
                placeholderTextColor={colors.mutedForeground}
                returnKeyType="next"
                style={[
                  styles.input,
                  {
                    color: colors.foreground,
                    backgroundColor: colors.card,
                    borderColor:
                      email.length > 0 && !validEmail
                        ? colors.destructive
                        : colors.border,
                  },
                ]}
                textContentType="emailAddress"
                value={email}
                testID="register-email"
              />
              {email.length > 0 && !validEmail ? (
                <Text style={[styles.errorText, { color: colors.destructive }]}>
                  Escribe un correo válido.
                </Text>
              ) : null}
            </View>

            <View style={styles.fieldGroup}>
              <Text style={[styles.label, { color: colors.foreground }]}>
                Contraseña
              </Text>
              <TextInput
                accessibilityLabel="Contraseña"
                autoCapitalize="none"
                autoComplete="new-password"
                maxLength={128}
                onChangeText={setPassword}
                placeholder="Al menos 6 caracteres"
                placeholderTextColor={colors.mutedForeground}
                returnKeyType="next"
                secureTextEntry
                style={[
                  styles.input,
                  {
                    color: colors.foreground,
                    backgroundColor: colors.card,
                    borderColor:
                      password.length > 0 && !validPassword
                        ? colors.destructive
                        : colors.border,
                  },
                ]}
                textContentType="newPassword"
                value={password}
                testID="register-password"
              />
              {password.length > 0 && !validPassword ? (
                <Text style={[styles.errorText, { color: colors.destructive }]}>
                  La contraseña debe tener al menos 6 caracteres.
                </Text>
              ) : null}
            </View>

            <View style={styles.fieldGroup}>
              <Text style={[styles.label, { color: colors.foreground }]}>
                Repite la contraseña
              </Text>
              <TextInput
                accessibilityLabel="Repite la contraseña"
                autoCapitalize="none"
                autoComplete="new-password"
                maxLength={128}
                onChangeText={setPasswordConfirmation}
                placeholder="Confirma tu contraseña"
                placeholderTextColor={colors.mutedForeground}
                returnKeyType="next"
                secureTextEntry
                style={[
                  styles.input,
                  {
                    color: colors.foreground,
                    backgroundColor: colors.card,
                    borderColor:
                      passwordConfirmation.length > 0 && !matchingPasswords
                        ? colors.destructive
                        : colors.border,
                  },
                ]}
                textContentType="newPassword"
                value={passwordConfirmation}
                testID="register-password-confirmation"
              />
              {passwordConfirmation.length > 0 && !matchingPasswords ? (
                <Text style={[styles.errorText, { color: colors.destructive }]}>
                  Las contraseñas no coinciden.
                </Text>
              ) : null}
            </View>
          </View>
        ) : null}

        <View style={styles.photoBlock}>
          <View
            style={[
              styles.photoFrame,
              { backgroundColor: colors.secondary, borderColor: colors.border },
            ]}
          >
            {isSupportedPhotoUrl(photoUri) ? (
              <Image source={{ uri: photoUri.trim() }} style={styles.photo} />
            ) : (
              <Feather name="user" size={25} color={colors.primary} />
            )}
          </View>
          <Text style={[styles.photoHelp, { color: colors.mutedForeground }]}>
            Vista previa
          </Text>
        </View>

        <View style={styles.fieldGroup}>
          <Text style={[styles.label, { color: colors.foreground }]}>
            URL de foto (opcional)
          </Text>
          <TextInput
            accessibilityLabel="URL de foto de perfil"
            autoCapitalize="none"
            autoCorrect={false}
            keyboardType="url"
            maxLength={2000}
            onChangeText={setPhotoUri}
            placeholder="https://ejemplo.com/mi-foto.jpg"
            placeholderTextColor={colors.mutedForeground}
            style={[
              styles.input,
              {
                color: colors.foreground,
                backgroundColor: colors.card,
                borderColor: trimmedPhotoUri && !validPhotoUri
                  ? colors.destructive
                  : colors.border,
              },
            ]}
            value={photoUri}
            testID="profile-photo-url"
          />
          <Text style={[styles.photoHelp, { color: colors.mutedForeground }]}>
            Usa un enlace HTTPS público a una imagen. WorldCall no sube ni almacena archivos de foto.
          </Text>
          {trimmedPhotoUri && !validPhotoUri ? (
            <Text style={[styles.errorText, { color: colors.destructive }]}>
              Escribe una URL HTTPS válida, distinta de Firebase Storage.
            </Text>
          ) : null}
        </View>

        <View style={styles.fieldGroup}>
          <Text style={[styles.label, { color: colors.foreground }]}>Nombre</Text>
          <TextInput
            accessibilityLabel="Nombre"
            autoCapitalize="words"
            maxLength={30}
            onChangeText={setName}
            placeholder="Cómo te llamamos"
            placeholderTextColor={colors.mutedForeground}
            returnKeyType="next"
            style={[
              styles.input,
              {
                color: colors.foreground,
                backgroundColor: colors.card,
                borderColor: colors.border,
              },
            ]}
            value={name}
            testID="profile-name"
          />
        </View>

        <View style={styles.fieldGroup}>
          <Text style={[styles.label, { color: colors.foreground }]}>Edad</Text>
          <TextInput
            accessibilityLabel="Edad"
            keyboardType="number-pad"
            maxLength={3}
            onChangeText={(value) => setAge(value.replace(/[^0-9]/g, ''))}
            placeholder="18 o más"
            placeholderTextColor={colors.mutedForeground}
            style={[
              styles.input,
              {
                color: colors.foreground,
                backgroundColor: colors.card,
                borderColor: invalidAge ? colors.destructive : colors.border,
              },
            ]}
            value={age}
            testID="profile-age"
          />
          {invalidAge ? (
            <Text style={[styles.errorText, { color: colors.destructive }]}>
              Debes tener al menos 18 años.
            </Text>
          ) : null}
        </View>

        <View style={styles.fieldGroup}>
          <Text style={[styles.label, { color: colors.foreground }]}>Sexo</Text>
          <View style={styles.choiceRow}>
            {GENDERS.map((option) => (
              <ChoiceChip
                key={option}
                label={option}
                selected={gender === option}
                onPress={() => setGender(option)}
                testID={`gender-${option}`}
              />
            ))}
          </View>
        </View>

        <View style={styles.fieldGroup}>
          <Text style={[styles.label, { color: colors.foreground }]}>País</Text>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Seleccionar país"
            onPress={() => setCountryPickerVisible(true)}
            style={({ pressed }) => [
              styles.select,
              {
                backgroundColor: colors.card,
                borderColor: colors.border,
                opacity: pressed ? 0.8 : 1,
              },
            ]}
            testID="profile-country"
          >
            <View style={styles.selectCopy}>
              <Feather name="map-pin" size={17} color={colors.primary} />
              <Text
                style={[
                  styles.selectText,
                  { color: country ? colors.foreground : colors.mutedForeground },
                ]}
              >
                {country || 'Selecciona tu país'}
              </Text>
            </View>
            <Feather name="chevron-down" size={19} color={colors.mutedForeground} />
          </Pressable>
        </View>

        <Pressable
          accessibilityRole="checkbox"
          accessibilityState={{ checked: confirmedAdult }}
          onPress={() => setConfirmedAdult((current) => !current)}
          style={styles.confirmRow}
          testID="confirm-adult"
        >
          <View
            style={[
              styles.checkbox,
              {
                borderColor: confirmedAdult ? colors.primary : colors.border,
                backgroundColor: confirmedAdult ? colors.primary : colors.card,
              },
            ]}
          >
            {confirmedAdult ? (
              <Feather name="check" size={14} color={colors.primaryForeground} />
            ) : null}
          </View>
          <Text style={[styles.confirmText, { color: colors.foreground }]}>
            Confirmo que tengo 18 años o más.
          </Text>
        </Pressable>

        <View style={[styles.localNote, { backgroundColor: colors.secondary }]}>
          <Feather name="lock" size={15} color={colors.primary} />
          <Text style={[styles.localNoteText, { color: colors.secondaryForeground }]}>
            Tu perfil y la URL de la foto se guardan en Firestore. Las
            preferencias, bloqueos y denuncias siguen guardándose en este dispositivo.
          </Text>
        </View>

        <AppButton
          label={
            isNewAccount
              ? 'Crear cuenta y guardar perfil'
              : initialProfile
                ? 'Guardar cambios'
                : 'Guardar perfil'
          }
          icon={isNewAccount ? 'arrow-right' : 'check'}
          onPress={submit}
          disabled={!ready || saving}
          loading={saving}
          style={styles.submit}
          testID="save-profile"
        />
      </KeyboardAwareScrollViewCompat>

      <CountryPicker
        visible={countryPickerVisible}
        selected={country}
        onClose={() => setCountryPickerVisible(false)}
        onSelect={setCountry}
      />
    </AppScreen>
  );
}

const styles = StyleSheet.create({
  content: {
    paddingHorizontal: 23,
    paddingTop: 8,
    paddingBottom: 28,
  },
  heading: {
    marginTop: 8,
    marginBottom: 17,
  },
  accountFields: {
    gap: 2,
  },
  photoBlock: {
    alignItems: 'center',
    marginBottom: 19,
    gap: 8,
  },
  photoFrame: {
    width: 82,
    height: 82,
    borderWidth: 1,
    borderRadius: 41,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  photo: {
    width: '100%',
    height: '100%',
    borderRadius: 41,
  },
  photoHelp: {
    fontFamily: 'Inter_500Medium',
    fontSize: 12,
  },
  fieldGroup: {
    gap: 8,
    marginBottom: 16,
  },
  label: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 14,
  },
  input: {
    height: 52,
    borderRadius: 15,
    borderWidth: 1,
    paddingHorizontal: 15,
    fontFamily: 'Inter_400Regular',
    fontSize: 15,
  },
  errorText: {
    fontFamily: 'Inter_500Medium',
    fontSize: 12,
  },
  choiceRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  select: {
    minHeight: 52,
    borderRadius: 15,
    borderWidth: 1,
    paddingHorizontal: 15,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  selectCopy: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  selectText: {
    fontFamily: 'Inter_500Medium',
    fontSize: 15,
  },
  confirmRow: {
    minHeight: 43,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 11,
  },
  checkbox: {
    width: 22,
    height: 22,
    borderWidth: 1,
    borderRadius: 7,
    alignItems: 'center',
    justifyContent: 'center',
  },
  confirmText: {
    fontFamily: 'Inter_500Medium',
    fontSize: 13,
  },
  localNote: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 9,
    padding: 13,
    borderRadius: 15,
    marginTop: 7,
  },
  localNoteText: {
    flex: 1,
    fontFamily: 'Inter_400Regular',
    fontSize: 12,
    lineHeight: 18,
  },
  submit: {
    marginTop: 18,
  },
});
