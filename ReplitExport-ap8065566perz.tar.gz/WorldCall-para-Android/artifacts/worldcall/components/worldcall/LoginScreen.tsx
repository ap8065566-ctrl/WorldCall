import { useState } from "react";
import {
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { KeyboardAwareScrollViewCompat } from "@/components/KeyboardAwareScrollViewCompat";
import { useColors } from "@/hooks/useColors";
import { firebaseErrorMessage } from "@/services/firebaseRepository";
import { AppButton, AppScreen, BackButton, StepTitle } from "./ui";

export function LoginScreen({
  onLogin,
  onCancel,
}: {
  onLogin: (email: string, password: string) => Promise<void>;
  onCancel: () => void;
}) {
  const colors = useColors();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  const submit = async () => {
    if (!email.trim() || !password) return;
    setErrorMessage("");
    setBusy(true);
    try {
      await onLogin(email, password);
    } catch (error) {
      setErrorMessage(firebaseErrorMessage(error));
    } finally {
      setBusy(false);
    }
  };

  return (
    <AppScreen>
      <KeyboardAwareScrollViewCompat
        contentContainerStyle={styles.content}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
        bottomOffset={70}
      >
        <BackButton onPress={onCancel} />
        <View style={styles.heading}>
          <StepTitle
            eyebrow="WorldCall"
            title="Inicia sesión"
            detail="Entra con el correo y la contraseña de tu cuenta."
          />
        </View>

        <View style={styles.fieldGroup}>
          <Text style={[styles.label, { color: colors.foreground }]}>
            Correo electrónico
          </Text>
          <TextInput
            accessibilityLabel="Correo electrónico"
            autoCapitalize="none"
            autoComplete="email"
            autoCorrect={false}
            keyboardType="email-address"
            onChangeText={setEmail}
            placeholder="nombre@ejemplo.com"
            placeholderTextColor={colors.mutedForeground}
            returnKeyType="next"
            style={[
              styles.input,
              {
                color: colors.foreground,
                backgroundColor: colors.card,
                borderColor: colors.border,
              },
            ]}
            textContentType="emailAddress"
            value={email}
            testID="login-email"
          />
        </View>

        <View style={styles.fieldGroup}>
          <Text style={[styles.label, { color: colors.foreground }]}>
            Contraseña
          </Text>
          <TextInput
            accessibilityLabel="Contraseña"
            autoCapitalize="none"
            autoComplete="current-password"
            onChangeText={setPassword}
            onSubmitEditing={() => void submit()}
            placeholder="Tu contraseña"
            placeholderTextColor={colors.mutedForeground}
            returnKeyType="go"
            secureTextEntry
            style={[
              styles.input,
              {
                color: colors.foreground,
                backgroundColor: colors.card,
                borderColor: colors.border,
              },
            ]}
            textContentType="password"
            value={password}
            testID="login-password"
          />
        </View>

        {errorMessage ? (
          <Text
            accessibilityRole="alert"
            style={[styles.errorText, { color: colors.destructive }]}
          >
            {errorMessage}
          </Text>
        ) : null}

        <AppButton
          label="Iniciar sesión"
          icon="log-in"
          onPress={() => void submit()}
          disabled={!email.trim() || !password || busy}
          loading={busy}
          style={styles.submit}
          testID="submit-login"
        />
      </KeyboardAwareScrollViewCompat>
    </AppScreen>
  );
}

const styles = StyleSheet.create({
  content: {
    paddingHorizontal: 23,
    paddingTop: 8,
    paddingBottom: 28,
  },
  heading: {
    marginTop: 12,
    marginBottom: 28,
  },
  fieldGroup: {
    gap: 8,
    marginBottom: 18,
  },
  label: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 14,
  },
  input: {
    height: 52,
    borderRadius: 15,
    borderWidth: 1,
    paddingHorizontal: 15,
    fontFamily: "Inter_400Regular",
    fontSize: 15,
  },
  errorText: {
    fontFamily: "Inter_500Medium",
    fontSize: 13,
    lineHeight: 19,
    marginBottom: 12,
  },
  submit: {
    marginTop: 8,
  },
});
