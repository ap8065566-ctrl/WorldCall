import { Image, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useColors } from '@/hooks/useColors';
import { AppButton, AppScreen, IconCircle } from './ui';

const profilePhotos = [
  require('../../assets/images/profile-lucia.jpg'),
  require('../../assets/images/profile-mateus.jpg'),
  require('../../assets/images/profile-yui.jpg'),
];

export function WelcomeScreen({
  hasLocalDraft,
  onCreate,
  onLogin,
}: {
  hasLocalDraft: boolean;
  onCreate: () => void;
  onLogin: () => void;
}) {
  const colors = useColors();
  return (
    <AppScreen>
      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.topRow}>
          <View style={styles.brand}>
            <Image
              source={require('../../assets/images/icon.png')}
              style={styles.logo}
              resizeMode="contain"
            />
            <Text style={[styles.brandName, { color: colors.foreground }]}>
              WorldCall
            </Text>
          </View>
          <View
            style={[
              styles.adultBadge,
              { backgroundColor: colors.accent, borderColor: colors.border },
            ]}
          >
            <Feather name="shield" size={13} color={colors.accentForeground} />
            <Text style={[styles.adultText, { color: colors.accentForeground }]}>
              18+
            </Text>
          </View>
        </View>

        <View style={styles.hero}>
          <View
            style={[
              styles.orbit,
              { backgroundColor: colors.secondary, borderColor: colors.border },
            ]}
          >
            <View style={[styles.orbitDot, { backgroundColor: colors.accent }]} />
            <View style={[styles.orbitCore, { backgroundColor: colors.primary }]}>
              <Feather name="globe" size={44} color={colors.primaryForeground} />
            </View>
            <View style={[styles.orbitDotSmall, { backgroundColor: colors.primary }]} />
          </View>
          <View style={styles.avatarRow}>
            {profilePhotos.map((photo, index) => (
              <Image
                key={index}
                source={photo}
                style={[
                  styles.avatar,
                  {
                    borderColor: colors.background,
                    marginLeft: index === 0 ? 0 : -13,
                  },
                ]}
              />
            ))}
            <View
              style={[
                styles.avatarMore,
                {
                  backgroundColor: colors.card,
                  borderColor: colors.background,
                  marginLeft: -11,
                },
              ]}
            >
              <Feather name="plus" size={17} color={colors.primary} />
            </View>
          </View>
        </View>

        <View style={styles.copy}>
          <Text style={[styles.kicker, { color: colors.primary }]}>
            EL MUNDO, MÁS CERCA
          </Text>
          <Text style={[styles.headline, { color: colors.foreground }]}>
            Una conversación{'\n'}puede cambiar tu día.
          </Text>
          <Text style={[styles.description, { color: colors.mutedForeground }]}>
            Descubre personas de distintos lugares y abre una conversación
            espontánea, sin importar la distancia.
          </Text>
        </View>

        <View style={styles.trustList}>
          <View style={styles.trustItem}>
            <IconCircle name="shield" size={34} iconSize={16} />
            <Text style={[styles.trustText, { color: colors.foreground }]}>
              Solo para mayores de 18
            </Text>
          </View>
          <View style={styles.trustItem}>
            <IconCircle name="video-off" size={34} iconSize={16} />
            <Text style={[styles.trustText, { color: colors.foreground }]}>
              Las llamadas no se graban
            </Text>
          </View>
        </View>

        <View style={styles.actions}>
          <AppButton
            label="Crear cuenta"
            icon="arrow-right"
            onPress={onCreate}
            testID="create-profile"
          />
          <AppButton
            label="Iniciar sesión"
            tone="outline"
            onPress={onLogin}
            testID="login-button"
          />
        </View>

        <View style={[styles.demoNote, { backgroundColor: colors.secondary }]}>
          <Feather name="info" size={15} color={colors.primary} />
          <Text style={[styles.demoText, { color: colors.secondaryForeground }]}>
            La cuenta, el perfil y la foto se guardan en Firebase. Las coincidencias
            y las videollamadas todavía son de demostración.
            {hasLocalDraft
              ? ' El perfil de prueba de este teléfono se usará como borrador; su copia local se elimina después de guardarlo en Firebase.'
              : ''}
          </Text>
        </View>
      </ScrollView>
    </AppScreen>
  );
}

const styles = StyleSheet.create({
  content: {
    paddingHorizontal: 25,
    paddingTop: 14,
    paddingBottom: 26,
  },
  topRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  brand: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  logo: {
    width: 36,
    height: 36,
    borderRadius: 11,
  },
  brandName: {
    fontFamily: 'Inter_700Bold',
    fontSize: 18,
    letterSpacing: -0.3,
  },
  adultBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 11,
    paddingVertical: 7,
    borderRadius: 14,
    borderWidth: 1,
  },
  adultText: {
    fontFamily: 'Inter_700Bold',
    fontSize: 12,
  },
  hero: {
    height: 244,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 16,
  },
  orbit: {
    width: 190,
    height: 190,
    borderRadius: 95,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  orbitCore: {
    width: 112,
    height: 112,
    borderRadius: 56,
    alignItems: 'center',
    justifyContent: 'center',
  },
  orbitDot: {
    position: 'absolute',
    width: 22,
    height: 22,
    borderRadius: 11,
    top: 25,
    left: 22,
  },
  orbitDotSmall: {
    position: 'absolute',
    width: 12,
    height: 12,
    borderRadius: 6,
    bottom: 21,
    right: 29,
  },
  avatarRow: {
    position: 'absolute',
    bottom: 4,
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    borderWidth: 3,
  },
  avatarMore: {
    width: 42,
    height: 42,
    borderRadius: 21,
    borderWidth: 3,
    justifyContent: 'center',
    alignItems: 'center',
  },
  copy: {
    gap: 11,
    marginTop: 4,
  },
  kicker: {
    fontFamily: 'Inter_700Bold',
    fontSize: 11,
    letterSpacing: 1.6,
  },
  headline: {
    fontFamily: 'Inter_700Bold',
    fontSize: 34,
    lineHeight: 40,
    letterSpacing: -1,
  },
  description: {
    fontFamily: 'Inter_400Regular',
    fontSize: 15,
    lineHeight: 23,
    maxWidth: 360,
  },
  trustList: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    columnGap: 17,
    rowGap: 10,
    marginTop: 19,
  },
  trustItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  trustText: {
    fontFamily: 'Inter_500Medium',
    fontSize: 12,
  },
  actions: {
    gap: 11,
    marginTop: 22,
  },
  demoNote: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 9,
    padding: 13,
    borderRadius: 16,
    marginTop: 16,
  },
  demoText: {
    flex: 1,
    fontFamily: 'Inter_400Regular',
    fontSize: 12,
    lineHeight: 18,
  },
});
