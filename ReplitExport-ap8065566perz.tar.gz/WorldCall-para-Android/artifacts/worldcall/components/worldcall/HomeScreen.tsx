import { useState } from 'react';
import { Image, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useColors } from '@/hooks/useColors';
import type {
  AgeRange,
  GenderFilter,
  MatchFilters,
  MemberProfile,
} from '@/types/worldcall';
import { AppButton, AppScreen, ChoiceChip, IconCircle, Panel } from './ui';
import { CountryPicker } from './CountryPicker';

const GENDER_FILTERS: GenderFilter[] = ['Todos', 'Mujeres', 'Hombres'];
const AGE_FILTERS: AgeRange[] = ['Todas', '18-24', '25-34', '35-49', '50+'];

export function HomeScreen({
  profile,
  filters,
  notice,
  onFiltersChange,
  onSearch,
  onProfile,
  onSignOut,
  onDismissNotice,
}: {
  profile: MemberProfile;
  filters: MatchFilters;
  notice: string;
  onFiltersChange: (filters: MatchFilters) => void;
  onSearch: () => void;
  onProfile: () => void;
  onSignOut: () => void;
  onDismissNotice: () => void;
}) {
  const colors = useColors();
  const [countryPickerVisible, setCountryPickerVisible] = useState(false);

  return (
    <AppScreen>
      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <View style={styles.brand}>
            <Image
              source={require('../../assets/images/icon.png')}
              style={styles.logo}
            />
            <Text style={[styles.brandName, { color: colors.foreground }]}>
              WorldCall
            </Text>
          </View>
          <View style={styles.headerActions}>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Editar perfil"
              onPress={onProfile}
              style={({ pressed }) => [
                styles.profileButton,
                {
                  borderColor: colors.border,
                  backgroundColor: colors.card,
                  opacity: pressed ? 0.7 : 1,
                },
              ]}
              testID="edit-profile"
            >
              {profile.photoUri ? (
                <Image source={{ uri: profile.photoUri }} style={styles.avatar} />
              ) : (
                <Text style={[styles.avatarLetter, { color: colors.primary }]}>
                  {profile.name.charAt(0).toUpperCase()}
                </Text>
              )}
            </Pressable>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Cerrar sesión"
              onPress={onSignOut}
              hitSlop={10}
              testID="sign-out"
            >
              <Feather name="log-out" size={18} color={colors.mutedForeground} />
            </Pressable>
          </View>
        </View>

        <View style={styles.intro}>
          <Text style={[styles.greeting, { color: colors.mutedForeground }]}>
            Hola, {profile.name}
          </Text>
          <Text style={[styles.heading, { color: colors.foreground }]}>
            ¿A quién te gustaría conocer?
          </Text>
          <Text style={[styles.description, { color: colors.mutedForeground }]}>
            Elige tus preferencias. Encontraremos una conversación nueva para ti.
          </Text>
        </View>

        {notice ? (
          <Pressable
            accessibilityRole="button"
            onPress={onDismissNotice}
            style={[styles.notice, { backgroundColor: colors.accent }]}
            testID="search-notice"
          >
            <Feather name="info" size={16} color={colors.accentForeground} />
            <Text style={[styles.noticeText, { color: colors.accentForeground }]}>
              {notice}
            </Text>
            <Feather name="x" size={16} color={colors.accentForeground} />
          </Pressable>
        ) : null}

        <Panel style={styles.filterPanel}>
          <View style={styles.sectionHeading}>
            <IconCircle name="users" size={37} iconSize={17} />
            <View style={styles.sectionCopy}>
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
                Quiero hablar con
              </Text>
              <Text style={[styles.helper, { color: colors.mutedForeground }]}>
                Puedes cambiarlo cuando quieras.
              </Text>
            </View>
          </View>
          <View style={styles.chips}>
            {GENDER_FILTERS.map((option) => (
              <ChoiceChip
                key={option}
                label={option}
                selected={filters.gender === option}
                onPress={() => onFiltersChange({ ...filters, gender: option })}
                testID={`filter-gender-${option}`}
              />
            ))}
          </View>

          <View style={[styles.separator, { backgroundColor: colors.border }]} />

          <View style={styles.filterLabelRow}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
              Edad
            </Text>
            <Text style={[styles.selectedValue, { color: colors.primary }]}>
              {filters.ageRange === 'Todas' ? '18 años o más' : filters.ageRange.replace('-', '–')}
            </Text>
          </View>
          <View style={styles.chips}>
            {AGE_FILTERS.map((option) => (
              <ChoiceChip
                key={option}
                label={option === 'Todas' ? 'Todas' : option.replace('-', '–')}
                selected={filters.ageRange === option}
                onPress={() => onFiltersChange({ ...filters, ageRange: option })}
                testID={`filter-age-${option}`}
              />
            ))}
          </View>

          <View style={[styles.separator, { backgroundColor: colors.border }]} />

          <View style={styles.filterLabelRow}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
              País
            </Text>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Elegir país para el filtro"
              onPress={() => setCountryPickerVisible(true)}
              style={({ pressed }) => [
                styles.countryButton,
                {
                  backgroundColor: colors.secondary,
                  opacity: pressed ? 0.75 : 1,
                },
              ]}
              testID="filter-country"
            >
              <Feather name="map-pin" size={15} color={colors.primary} />
              <Text style={[styles.countryText, { color: colors.secondaryForeground }]}>
                {filters.country}
              </Text>
              <Feather name="chevron-down" size={15} color={colors.secondaryForeground} />
            </Pressable>
          </View>
        </Panel>

        <View style={styles.safetyRow}>
          <IconCircle name="shield" size={34} iconSize={16} />
          <Text style={[styles.safetyText, { color: colors.mutedForeground }]}>
            Solo adultos · Sin grabación de llamadas
          </Text>
        </View>

        <AppButton
          label="Buscar persona"
          icon="search"
          onPress={onSearch}
          style={styles.searchButton}
          testID="search-person"
        />
        <Text style={[styles.demoCaption, { color: colors.mutedForeground }]}>
          Versión de prueba · las coincidencias son perfiles de ejemplo
        </Text>

        <View style={[styles.localMode, { borderColor: colors.border }]}>
          <Feather name="cloud" size={15} color={colors.mutedForeground} />
          <Text style={[styles.localModeText, { color: colors.mutedForeground }]}>
            Tu perfil está en Firebase; preferencias, bloqueos y denuncias siguen en este teléfono.
          </Text>
        </View>
      </ScrollView>

      <CountryPicker
        visible={countryPickerVisible}
        selected={filters.country}
        allowAny
        onClose={() => setCountryPickerVisible(false)}
        onSelect={(country) => onFiltersChange({ ...filters, country })}
      />
    </AppScreen>
  );
}

const styles = StyleSheet.create({
  content: {
    paddingHorizontal: 22,
    paddingTop: 10,
    paddingBottom: 25,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  brand: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  logo: {
    width: 34,
    height: 34,
    borderRadius: 11,
  },
  brandName: {
    fontFamily: 'Inter_700Bold',
    fontSize: 17,
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 17,
  },
  profileButton: {
    width: 39,
    height: 39,
    borderRadius: 20,
    borderWidth: 1,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatar: {
    width: '100%',
    height: '100%',
  },
  avatarLetter: {
    fontFamily: 'Inter_700Bold',
    fontSize: 16,
  },
  intro: {
    gap: 6,
    marginTop: 25,
    marginBottom: 19,
  },
  greeting: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 13,
  },
  heading: {
    fontFamily: 'Inter_700Bold',
    fontSize: 27,
    lineHeight: 33,
    letterSpacing: -0.6,
  },
  description: {
    fontFamily: 'Inter_400Regular',
    fontSize: 14,
    lineHeight: 21,
  },
  notice: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 9,
    paddingHorizontal: 13,
    paddingVertical: 12,
    borderRadius: 15,
    marginBottom: 14,
  },
  noticeText: {
    flex: 1,
    fontFamily: 'Inter_500Medium',
    fontSize: 12,
    lineHeight: 17,
  },
  filterPanel: {
    gap: 15,
    padding: 17,
  },
  sectionHeading: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 11,
  },
  sectionCopy: {
    flex: 1,
    gap: 3,
  },
  sectionTitle: {
    fontFamily: 'Inter_700Bold',
    fontSize: 15,
  },
  helper: {
    fontFamily: 'Inter_400Regular',
    fontSize: 12,
  },
  chips: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 7,
  },
  separator: {
    height: StyleSheet.hairlineWidth,
    width: '100%',
    marginVertical: 1,
  },
  filterLabelRow: {
    minHeight: 25,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: 10,
  },
  selectedValue: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 12,
  },
  countryButton: {
    minHeight: 37,
    maxWidth: '70%',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
    borderRadius: 13,
    paddingHorizontal: 11,
  },
  countryText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 12,
    flexShrink: 1,
  },
  safetyRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 9,
    marginTop: 14,
  },
  safetyText: {
    fontFamily: 'Inter_500Medium',
    fontSize: 12,
  },
  searchButton: {
    marginTop: 14,
  },
  demoCaption: {
    textAlign: 'center',
    fontFamily: 'Inter_400Regular',
    fontSize: 11,
    marginTop: 10,
  },
  localMode: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 9,
    borderTopWidth: StyleSheet.hairlineWidth,
    marginTop: 19,
    paddingTop: 14,
  },
  localModeText: {
    flex: 1,
    fontFamily: 'Inter_400Regular',
    fontSize: 11,
    lineHeight: 16,
  },
});
