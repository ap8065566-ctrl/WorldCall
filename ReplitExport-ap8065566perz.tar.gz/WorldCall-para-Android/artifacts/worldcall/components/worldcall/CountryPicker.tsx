import { useState } from 'react';
import {
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useColors } from '@/hooks/useColors';

export const COUNTRIES = [
  'España',
  'Brasil',
  'Japón',
  'México',
  'Argentina',
  'Canadá',
  'Estados Unidos',
  'Francia',
  'Alemania',
  'Italia',
  'India',
  'Reino Unido',
  'Australia',
  'Colombia',
  'Chile',
  'Cualquier país',
];

export function CountryPicker({
  visible,
  selected,
  allowAny = false,
  onClose,
  onSelect,
}: {
  visible: boolean;
  selected: string;
  allowAny?: boolean;
  onClose: () => void;
  onSelect: (country: string) => void;
}) {
  const colors = useColors();
  const [query, setQuery] = useState('');
  const options = COUNTRIES.filter((country) => {
    if (!allowAny && country === 'Cualquier país') return false;
    return country.toLocaleLowerCase().includes(query.trim().toLocaleLowerCase());
  });

  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={onClose}
    >
      <View style={styles.overlay}>
        <Pressable
          accessibilityLabel="Cerrar selector de país"
          onPress={onClose}
          style={[
            StyleSheet.absoluteFill,
            { backgroundColor: colors.foreground, opacity: 0.45 },
          ]}
        />
        <View style={[styles.sheet, { backgroundColor: colors.card }]}>
          <View style={[styles.handle, { backgroundColor: colors.border }]} />
          <View style={styles.headingRow}>
            <View style={styles.headingCopy}>
              <Text style={[styles.title, { color: colors.foreground }]}>
                Elige un país
              </Text>
              <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
                {allowAny
                  ? 'Filtra por lugar o descubre a alguien de cualquier parte.'
                  : 'Indica dónde vives.'}
              </Text>
            </View>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Cerrar"
              onPress={onClose}
              hitSlop={10}
            >
              <Feather name="x" size={23} color={colors.mutedForeground} />
            </Pressable>
          </View>

          <View
            style={[
              styles.searchBox,
              { backgroundColor: colors.background, borderColor: colors.border },
            ]}
          >
            <Feather name="search" size={17} color={colors.mutedForeground} />
            <TextInput
              accessibilityLabel="Buscar país"
              value={query}
              onChangeText={setQuery}
              placeholder="Buscar"
              placeholderTextColor={colors.mutedForeground}
              style={[styles.searchInput, { color: colors.foreground }]}
              testID="country-search"
            />
          </View>

          <ScrollView
            style={styles.list}
            keyboardShouldPersistTaps="handled"
            showsVerticalScrollIndicator={false}
          >
            {options.map((country) => {
              const active = country === selected;
              return (
                <Pressable
                  key={country}
                  accessibilityRole="button"
                  accessibilityState={{ selected: active }}
                  onPress={() => {
                    onSelect(country);
                    setQuery('');
                    onClose();
                  }}
                  style={[
                    styles.option,
                    {
                      backgroundColor: active ? colors.secondary : 'transparent',
                      borderColor: colors.border,
                    },
                  ]}
                  testID={`country-${country}`}
                >
                  <Text
                    style={[
                      styles.optionText,
                      { color: active ? colors.primary : colors.foreground },
                    ]}
                  >
                    {country}
                  </Text>
                  {active ? (
                    <Feather name="check" size={18} color={colors.primary} />
                  ) : null}
                </Pressable>
              );
            })}
            {options.length === 0 ? (
              <Text style={[styles.empty, { color: colors.mutedForeground }]}>
                No se encontró ese país.
              </Text>
            ) : null}
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    justifyContent: 'flex-end',
  },
  sheet: {
    maxHeight: '82%',
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    paddingHorizontal: 22,
    paddingTop: 12,
    paddingBottom: 26,
  },
  handle: {
    alignSelf: 'center',
    width: 38,
    height: 4,
    borderRadius: 3,
    marginBottom: 19,
  },
  headingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 20,
    marginBottom: 16,
  },
  headingCopy: {
    flex: 1,
    gap: 5,
  },
  title: {
    fontFamily: 'Inter_700Bold',
    fontSize: 21,
  },
  subtitle: {
    fontFamily: 'Inter_400Regular',
    fontSize: 13,
    lineHeight: 19,
  },
  searchBox: {
    height: 48,
    borderWidth: 1,
    borderRadius: 15,
    paddingHorizontal: 14,
    alignItems: 'center',
    flexDirection: 'row',
    gap: 10,
    marginBottom: 11,
  },
  searchInput: {
    flex: 1,
    height: '100%',
    fontFamily: 'Inter_400Regular',
    fontSize: 15,
  },
  list: {
    flexGrow: 0,
  },
  option: {
    minHeight: 50,
    borderBottomWidth: StyleSheet.hairlineWidth,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 12,
    borderRadius: 12,
  },
  optionText: {
    fontFamily: 'Inter_500Medium',
    fontSize: 15,
  },
  empty: {
    textAlign: 'center',
    fontFamily: 'Inter_400Regular',
    paddingVertical: 18,
  },
});
