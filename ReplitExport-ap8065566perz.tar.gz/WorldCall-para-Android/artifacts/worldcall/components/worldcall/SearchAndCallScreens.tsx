import { useState } from 'react';
import {
  Image,
  ImageBackground,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useColors } from '@/hooks/useColors';
import type { DemoMatch, MemberProfile } from '@/types/worldcall';
import { AppButton, AppScreen, IconCircle, Panel } from './ui';

export function SearchingScreen({ onCancel }: { onCancel: () => void }) {
  const colors = useColors();
  return (
    <AppScreen>
      <View style={searchStyles.screen}>
        <View style={searchStyles.brand}>
          <Image
            source={require('../../assets/images/icon.png')}
            style={searchStyles.logo}
          />
          <Text style={[searchStyles.brandName, { color: colors.foreground }]}>
            WorldCall
          </Text>
        </View>

        <View style={searchStyles.center}>
          <View
            style={[
              searchStyles.searchOrb,
              { backgroundColor: colors.secondary, borderColor: colors.border },
            ]}
          >
            <View
              style={[
                searchStyles.searchInner,
                { backgroundColor: colors.primary },
              ]}
            >
              <Feather name="globe" size={38} color={colors.primaryForeground} />
            </View>
            <View
              style={[
                searchStyles.pulseDot,
                { backgroundColor: colors.accentForeground },
              ]}
            />
          </View>
          <Text style={[searchStyles.title, { color: colors.foreground }]}>
            Buscando a alguien nuevo
          </Text>
          <Text style={[searchStyles.detail, { color: colors.mutedForeground }]}>
            Aplicando tus filtros de edad, país y preferencias.
          </Text>
          <View
            style={[
              searchStyles.matchingTag,
              { backgroundColor: colors.secondary },
            ]}
          >
            <View
              style={[
                searchStyles.liveDot,
                { backgroundColor: colors.primary },
              ]}
            />
            <Text
              style={[
                searchStyles.matchingText,
                { color: colors.secondaryForeground },
              ]}
            >
              Emparejamiento de demostración
            </Text>
          </View>
        </View>

        <AppButton
          label="Cancelar búsqueda"
          tone="outline"
          icon="x"
          onPress={onCancel}
          testID="cancel-search"
        />
      </View>
    </AppScreen>
  );
}

const REPORT_REASONS = [
  'Contenido inapropiado',
  'Comportamiento ofensivo',
  'No me siento cómodo/a',
  'Otro motivo',
];

export function CallScreen({
  match,
  profile,
  onNext,
  onBlock,
  onReport,
}: {
  match: DemoMatch;
  profile: MemberProfile;
  onNext: () => void;
  onBlock: () => void;
  onReport: (reason: string) => void;
}) {
  const colors = useColors();
  const [reportOpen, setReportOpen] = useState(false);
  const [reason, setReason] = useState(REPORT_REASONS[0] ?? '');

  return (
    <AppScreen>
      <View style={callStyles.screen}>
        <ImageBackground
          source={match.photo}
          resizeMode="cover"
          style={callStyles.photo}
          imageStyle={callStyles.photoImage}
        >
          <View style={callStyles.photoTop}>
            <View
              style={[
                callStyles.demoBadge,
                { backgroundColor: colors.card, borderColor: colors.border },
              ]}
            >
              <View
                style={[
                  callStyles.demoDot,
                  { backgroundColor: colors.primary },
                ]}
              />
              <Text style={[callStyles.demoBadgeText, { color: colors.foreground }]}>
                VISTA PREVIA
              </Text>
            </View>
            <View
              style={[
                callStyles.cameraNotice,
                { backgroundColor: colors.card },
              ]}
            >
              <Feather name="video-off" size={14} color={colors.accentForeground} />
              <Text
                style={[
                  callStyles.cameraNoticeText,
                  { color: colors.accentForeground },
                ]}
              >
                Vídeo aún no conectado
              </Text>
            </View>
          </View>

          <View
            style={[
              callStyles.matchCopy,
              { backgroundColor: colors.foreground },
            ]}
          >
            <View style={callStyles.matchInfo}>
              <Text style={[callStyles.name, { color: colors.background }]}>
                {match.name}, {match.age}
              </Text>
              <View style={callStyles.location}>
                <Feather name="map-pin" size={14} color={colors.background} />
                <Text
                  style={[
                    callStyles.locationText,
                    { color: colors.background },
                  ]}
                >
                  {match.city}, {match.country}
                </Text>
              </View>
            </View>
            <View
              style={[
                callStyles.selfPreview,
                { borderColor: colors.card },
              ]}
            >
              {profile.photoUri ? (
                <Image
                  source={{ uri: profile.photoUri }}
                  style={callStyles.selfPhoto}
                />
              ) : (
                <View
                  style={[
                    callStyles.selfFallback,
                    { backgroundColor: colors.secondary },
                  ]}
                >
                  <Feather name="user" size={22} color={colors.primary} />
                </View>
              )}
              <Text
                style={[
                  callStyles.selfName,
                  {
                    color: colors.background,
                    backgroundColor: colors.foreground,
                  },
                ]}
              >
                Tú
              </Text>
            </View>
          </View>
        </ImageBackground>

        <ScrollView
          contentContainerStyle={callStyles.controls}
          showsVerticalScrollIndicator={false}
        >
          <View style={callStyles.callLabel}>
            <View
              style={[
                callStyles.callLabelIcon,
                { backgroundColor: colors.secondary },
              ]}
            >
              <Feather name="monitor" size={15} color={colors.primary} />
            </View>
            <Text style={[callStyles.callLabelText, { color: colors.mutedForeground }]}>
              Pantalla preparada para videollamada
            </Text>
          </View>

          <Panel style={callStyles.privacyPanel}>
            <IconCircle name="shield" size={36} iconSize={17} />
            <View style={callStyles.privacyCopy}>
              <Text style={[callStyles.privacyTitle, { color: colors.foreground }]}>
                Mantén una conversación segura
              </Text>
              <Text style={[callStyles.privacyText, { color: colors.mutedForeground }]}>
                Si algo no va bien, puedes pasar, bloquear o denunciar.
              </Text>
            </View>
          </Panel>

          <AppButton
            label="Siguiente"
            icon="skip-forward"
            onPress={onNext}
            testID="next-match"
          />

          <View style={callStyles.secondaryActions}>
            <Pressable
              accessibilityRole="button"
              onPress={onBlock}
              style={({ pressed }) => [
                callStyles.secondaryAction,
                {
                  backgroundColor: colors.card,
                  borderColor: colors.border,
                  opacity: pressed ? 0.68 : 1,
                },
              ]}
              testID="block-match"
            >
              <Feather name="slash" size={17} color={colors.destructive} />
              <Text style={[callStyles.secondaryActionText, { color: colors.foreground }]}>
                Bloquear
              </Text>
            </Pressable>
            <Pressable
              accessibilityRole="button"
              onPress={() => setReportOpen(true)}
              style={({ pressed }) => [
                callStyles.secondaryAction,
                {
                  backgroundColor: colors.card,
                  borderColor: colors.border,
                  opacity: pressed ? 0.68 : 1,
                },
              ]}
              testID="report-match"
            >
              <Feather name="flag" size={17} color={colors.destructive} />
              <Text style={[callStyles.secondaryActionText, { color: colors.foreground }]}>
                Denunciar
              </Text>
            </Pressable>
          </View>
        </ScrollView>
      </View>

      <Modal
        visible={reportOpen}
        transparent
        animationType="fade"
        onRequestClose={() => setReportOpen(false)}
      >
        <View style={callStyles.modalOverlay}>
          <Pressable
            accessibilityLabel="Cerrar denuncia"
            onPress={() => setReportOpen(false)}
            style={[
              StyleSheet.absoluteFill,
              { backgroundColor: colors.foreground, opacity: 0.48 },
            ]}
          />
          <View style={[callStyles.reportCard, { backgroundColor: colors.card }]}>
            <View style={callStyles.reportHeader}>
              <View
                style={[
                  callStyles.reportIcon,
                  { backgroundColor: colors.accent },
                ]}
              >
                <Feather name="flag" size={19} color={colors.destructive} />
              </View>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Cerrar denuncia"
                onPress={() => setReportOpen(false)}
                hitSlop={10}
              >
                <Feather name="x" size={21} color={colors.mutedForeground} />
              </Pressable>
            </View>
            <Text style={[callStyles.reportTitle, { color: colors.foreground }]}>
              ¿Qué ha ocurrido?
            </Text>
            <Text style={[callStyles.reportSubtitle, { color: colors.mutedForeground }]}>
              La denuncia se guardará solo en este dispositivo en esta versión de prueba.
            </Text>
            <View style={callStyles.reasonList}>
              {REPORT_REASONS.map((item) => {
                const selected = reason === item;
                return (
                  <Pressable
                    key={item}
                    accessibilityRole="radio"
                    accessibilityState={{ selected }}
                    onPress={() => setReason(item)}
                    style={[
                      callStyles.reasonRow,
                      {
                        borderColor: selected ? colors.primary : colors.border,
                        backgroundColor: selected ? colors.secondary : colors.card,
                      },
                    ]}
                  >
                    <View
                      style={[
                        callStyles.radio,
                        { borderColor: selected ? colors.primary : colors.border },
                      ]}
                    >
                      {selected ? (
                        <View
                          style={[
                            callStyles.radioInner,
                            { backgroundColor: colors.primary },
                          ]}
                        />
                      ) : null}
                    </View>
                    <Text style={[callStyles.reasonText, { color: colors.foreground }]}>
                      {item}
                    </Text>
                  </Pressable>
                );
              })}
            </View>
            <AppButton
              label="Enviar denuncia"
              tone="danger"
              icon="send"
              onPress={() => {
                setReportOpen(false);
                onReport(reason);
              }}
              testID="submit-report"
            />
          </View>
        </View>
      </Modal>
    </AppScreen>
  );
}

const searchStyles = StyleSheet.create({
  screen: {
    flex: 1,
    paddingHorizontal: 24,
    paddingTop: 14,
    paddingBottom: 26,
  },
  brand: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 9,
  },
  logo: {
    width: 35,
    height: 35,
    borderRadius: 11,
  },
  brandName: {
    fontFamily: 'Inter_700Bold',
    fontSize: 17,
  },
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 14,
  },
  searchOrb: {
    width: 176,
    height: 176,
    borderWidth: 1,
    borderRadius: 88,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 31,
  },
  searchInner: {
    width: 104,
    height: 104,
    borderRadius: 52,
    alignItems: 'center',
    justifyContent: 'center',
  },
  pulseDot: {
    position: 'absolute',
    width: 16,
    height: 16,
    borderRadius: 8,
    top: 15,
    right: 28,
  },
  title: {
    fontFamily: 'Inter_700Bold',
    fontSize: 23,
    textAlign: 'center',
    marginBottom: 9,
  },
  detail: {
    fontFamily: 'Inter_400Regular',
    fontSize: 14,
    lineHeight: 21,
    textAlign: 'center',
    maxWidth: 300,
  },
  matchingTag: {
    marginTop: 22,
    minHeight: 34,
    paddingHorizontal: 12,
    borderRadius: 17,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  liveDot: {
    width: 7,
    height: 7,
    borderRadius: 4,
  },
  matchingText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 11,
  },
});

const callStyles = StyleSheet.create({
  screen: {
    flex: 1,
    paddingHorizontal: 14,
    paddingTop: 8,
    paddingBottom: 8,
  },
  photo: {
    flex: 1,
    minHeight: 350,
    borderRadius: 27,
    overflow: 'hidden',
    justifyContent: 'space-between',
  },
  photoImage: {
    borderRadius: 27,
  },
  photoTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    padding: 13,
    gap: 8,
  },
  demoBadge: {
    minHeight: 31,
    paddingHorizontal: 10,
    borderRadius: 11,
    borderWidth: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
  },
  demoDot: {
    width: 7,
    height: 7,
    borderRadius: 4,
  },
  demoBadgeText: {
    fontFamily: 'Inter_700Bold',
    fontSize: 10,
    letterSpacing: 0.7,
  },
  cameraNotice: {
    minHeight: 31,
    paddingHorizontal: 9,
    borderRadius: 11,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
  },
  cameraNoticeText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 10,
  },
  matchCopy: {
    paddingHorizontal: 17,
    paddingBottom: 16,
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    gap: 12,
  },
  matchInfo: {
    flex: 1,
    gap: 7,
  },
  name: {
    fontFamily: 'Inter_700Bold',
    fontSize: 30,
    letterSpacing: -0.5,
  },
  location: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  locationText: {
    fontFamily: 'Inter_500Medium',
    fontSize: 13,
  },
  selfPreview: {
    width: 68,
    height: 94,
    borderRadius: 17,
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: 'transparent',
    alignItems: 'center',
    justifyContent: 'center',
  },
  selfPhoto: {
    ...StyleSheet.absoluteFill,
    width: undefined,
    height: undefined,
    resizeMode: 'cover',
  },
  selfFallback: {
    ...StyleSheet.absoluteFill,
    alignItems: 'center',
    justifyContent: 'center',
  },
  selfName: {
    position: 'absolute',
    bottom: 5,
    fontFamily: 'Inter_600SemiBold',
    fontSize: 10,
    overflow: 'hidden',
  },
  controls: {
    paddingTop: 12,
    paddingBottom: 8,
    gap: 10,
  },
  callLabel: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    justifyContent: 'center',
  },
  callLabelIcon: {
    width: 27,
    height: 27,
    borderRadius: 9,
    alignItems: 'center',
    justifyContent: 'center',
  },
  callLabelText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 12,
  },
  privacyPanel: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    gap: 10,
    borderRadius: 18,
  },
  privacyCopy: {
    flex: 1,
    gap: 3,
  },
  privacyTitle: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 13,
  },
  privacyText: {
    fontFamily: 'Inter_400Regular',
    fontSize: 11,
    lineHeight: 16,
  },
  secondaryActions: {
    flexDirection: 'row',
    gap: 9,
  },
  secondaryAction: {
    flex: 1,
    height: 48,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    borderRadius: 15,
    borderWidth: 1,
  },
  secondaryActionText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 13,
  },
  modalOverlay: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
  },
  reportCard: {
    borderRadius: 26,
    padding: 21,
  },
  reportHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 13,
  },
  reportIcon: {
    width: 39,
    height: 39,
    borderRadius: 13,
    alignItems: 'center',
    justifyContent: 'center',
  },
  reportTitle: {
    fontFamily: 'Inter_700Bold',
    fontSize: 21,
    marginBottom: 6,
  },
  reportSubtitle: {
    fontFamily: 'Inter_400Regular',
    fontSize: 13,
    lineHeight: 19,
    marginBottom: 15,
  },
  reasonList: {
    gap: 8,
    marginBottom: 17,
  },
  reasonRow: {
    minHeight: 45,
    borderWidth: 1,
    borderRadius: 14,
    paddingHorizontal: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  radio: {
    width: 18,
    height: 18,
    borderWidth: 1.5,
    borderRadius: 9,
    justifyContent: 'center',
    alignItems: 'center',
  },
  radioInner: {
    width: 9,
    height: 9,
    borderRadius: 5,
  },
  reasonText: {
    fontFamily: 'Inter_500Medium',
    fontSize: 13,
  },
});
