export type Gender = 'Mujer' | 'Hombre' | 'Prefiero no decirlo';
export type GenderFilter = 'Todos' | 'Mujeres' | 'Hombres';
export type AgeRange = 'Todas' | '18-24' | '25-34' | '35-49' | '50+';

export interface MemberProfile {
  name: string;
  age: number;
  gender: Gender;
  country: string;
  photoUri: string | null;
}

export interface MatchFilters {
  gender: GenderFilter;
  ageRange: AgeRange;
  country: string;
}

export interface DemoMatch {
  id: string;
  name: string;
  age: number;
  gender: 'Mujer' | 'Hombre';
  country: string;
  city: string;
  photo: number;
}
