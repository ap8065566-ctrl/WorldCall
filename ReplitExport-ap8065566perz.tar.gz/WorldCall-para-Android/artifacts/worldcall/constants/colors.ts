/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    // Legacy aliases (kept for backward compatibility)
    text: '#183034',
    tint: '#167E78',

    // Core surfaces
    background: '#F5F5F0',
    foreground: '#183034',

    // Cards / elevated surfaces
    card: '#FFFFFF',
    cardForeground: '#183034',

    // Primary action color (buttons, links, active states)
    primary: '#167E78',
    primaryForeground: '#FFFFFF',

    // Secondary / less-emphasis interactive surfaces
    secondary: '#E8F0ED',
    secondaryForeground: '#24504E',

    // Muted / subdued elements (dividers, timestamps, placeholders)
    muted: '#E9ECE7',
    mutedForeground: '#687875',

    // Accent highlights (badges, selected items, focus rings)
    accent: '#F9E3D8',
    accentForeground: '#783F31',

    // Destructive actions (delete, error states)
    destructive: '#B7434A',
    destructiveForeground: '#FFFFFF',

    // Borders and input outlines
    border: '#DCE4DF',
    input: '#DCE4DF',
  },
  dark: {
    text: '#E6F0ED',
    tint: '#59C8B6',
    background: '#102124',
    foreground: '#E6F0ED',
    card: '#193034',
    cardForeground: '#E6F0ED',
    primary: '#59C8B6',
    primaryForeground: '#102124',
    secondary: '#213A3D',
    secondaryForeground: '#C4DFD8',
    muted: '#203437',
    mutedForeground: '#A0B6B1',
    accent: '#49352F',
    accentForeground: '#FFD8C7',
    destructive: '#D66B70',
    destructiveForeground: '#FFFFFF',
    border: '#315052',
    input: '#315052',
  },

  // Border radius (in px). Sync from the sibling web artifact's --radius
  // CSS variable. This value applies to cards, buttons, inputs, and modals.
  radius: 20,
};

export default colors;
