# WorldCall

Aplicación móvil Android para adultos que buscan conversaciones aleatorias con personas de otros países.

## Run & Operate

- `pnpm --filter @workspace/worldcall run dev` — run the Expo app
- `pnpm --filter @workspace/worldcall run typecheck` — typecheck the mobile app
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- The first version uses on-device demo data; the API server and database are not required by WorldCall yet.

## Stack

- pnpm workspace, Expo, Expo Router, React Native, TypeScript
- AsyncStorage-backed local repository for prototype profiles, filters, blocks, and reports
- Expo Image Picker for optional profile photos

## Where things live

- `artifacts/worldcall/app/` — Expo Router screens and root layout
- `artifacts/worldcall/components/worldcall/` — welcome, profile, search, and call-preview screens
- `artifacts/worldcall/services/localRepository.ts` — local persistence boundary to replace with Firebase-backed storage later
- `artifacts/worldcall/data/demoProfiles.ts` — fictional demo profiles and local filter matching
- `artifacts/worldcall/constants/colors.ts` — shared light/dark theme tokens

## Architecture decisions

- Keep profile, filter, block, and report persistence behind a repository interface so Firebase can replace AsyncStorage without changing screens.
- Keep the call-preview UI separate from matchmaking; WebRTC media transport is intentionally not implemented yet.
- Match profiles are fictional demo content; never present the local candidate list as live users.
- Profile age must be at least 18. Do not add call recording or call storage.

## Product

WorldCall is an 18+ random video-chat product concept. The current prototype supports local profile setup, photo selection, gender/age/country filters, demo matchmaking, and local block/report actions. Its call screen is a preview only; camera and WebRTC are not connected.

## User preferences

- Do not add payments in the first version.
- Do not record or store video calls.
- Keep the product restricted to users aged 18 and older.
- Plan for Firebase user/data services and WebRTC calls as later additions.

## Gotchas

- This prototype does not create secure accounts or connect real users; do not describe local profile storage as production authentication.
- The demo matcher has a small fixed set of fictional profiles, so some filter combinations intentionally return no results.
- Android is the requested target. Do not suggest iOS publishing as the delivery path.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
