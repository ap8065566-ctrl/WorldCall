---
name: Firebase Auth in Expo
description: Platform-specific Firebase JS Auth persistence behavior in WorldCall's Expo app.
---

For native Expo, initialize Firebase Auth with `getReactNativePersistence(AsyncStorage)` so sessions survive app restarts. Keep the web entry on Firebase's browser defaults. In the installed Firebase SDK, `getReactNativePersistence` exists in the React Native conditional entry but is missing from the umbrella `firebase/auth` TypeScript declarations; the native entry therefore uses a narrowly typed namespace cast instead of importing Firebase internals.

**Why:** The public React Native bundle provides persistent storage, while the default React Native `getAuth()` path warns that sessions otherwise stay in memory. TypeScript can report a missing named export even though Metro's Android bundle includes the React Native implementation.

**How to apply:** When changing Firebase Auth setup or upgrading Firebase in this Expo app, preserve the platform split and verify both `pnpm --filter @workspace/worldcall run typecheck` and an Android Expo export.
